exports.CHAT_TYPE  = [
    "TEXT",
    "IMAGE",
    "AUDIO",
    "VIDEO",
]

exports.CHAT_STATUS = [
    "QUEUED",
    "SENT",
]

exports.CHAT_REQUEST_STATUS = [
  "PENDING",
  "ACCEPTED",
  "REJECTED"
];
