let React = require('react');

import './cv.css';
const CV = (props) => {
  return (<div>
    <p>CV</p>
  </div>);
}

module.exports = CV;
